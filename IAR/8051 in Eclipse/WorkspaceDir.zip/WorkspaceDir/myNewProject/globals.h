/*
 * globals.h
 *
 *  Created on: Jun 21, 2017
 *      Author: Justin
 */

#ifndef GLOBALS_H_
#define GLOBALS_H_



#endif /* GLOBALS_H_ */
