#include "globals.h"


int main(void) {

  volatile int i = 0;
  
  i++;
  
  i++;

  return 0;
}



